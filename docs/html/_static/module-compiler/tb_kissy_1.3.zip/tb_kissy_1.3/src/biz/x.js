KISSY.add(function(){
},{
    requires:["overlay","switchable"]
});