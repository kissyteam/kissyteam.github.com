KISSY.add(function(){
},{
    requires:["../y"]
})