KISSY.add("biz/x", function() {
}, {requires:["overlay", "switchable"]});

