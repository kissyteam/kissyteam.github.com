KISSY.add("biz/y", function(S, x) {
  return"y + " + x
}, {requires:["./x"]});

