KISSY.add("biz/page/run", function (S, y) {
    return 'run + ' + y;
}, {requires: ["../y"]});

