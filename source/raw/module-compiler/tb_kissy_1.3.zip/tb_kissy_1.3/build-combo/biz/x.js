KISSY.add("biz/x", function() {
  return"x + overlay + switchable"
}, {requires:["overlay", "switchable"]});

