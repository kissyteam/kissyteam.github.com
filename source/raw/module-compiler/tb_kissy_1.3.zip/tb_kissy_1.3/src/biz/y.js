KISSY.add(function(S, x) {
  return"y + " + x
}, {requires:["./x"]});

