KISSY.add(function() {
  return"x + overlay + switchable"
}, {requires:["overlay", "switchable"]});

