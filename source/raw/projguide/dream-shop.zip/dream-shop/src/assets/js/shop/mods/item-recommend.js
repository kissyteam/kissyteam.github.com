KISSY.add(function(S,Core,Compatible){
    var S = KISSY, E = S.Event, D = S.DOM;
    var  DISAPPEAR = 'disappear',
         SUCCESS = 'success',
         WARN = 'warn',
         FAILURE = 'failure';
    var MINMAX_CONFIG = {
      'grid-m':{'item3line1':[0,0,310,310], 'item4line1':[0,0,230,230], 'item5line1':[0,0,180,180], 'item7line1':[0,0,130,130]},
      'grid-m0':{'item3line1':[0,0,310,310], 'item4line1':[0,0,230,230], 'item5line1':[0,0,180,180], 'item7line1':[0,0,130,130]},
      'grid-s5m0':{'item3line1':[0,0,240,240], 'item30line1':[0,0,248,248], 'item4line1':[0,0,180,180]},//col-main
      'grid-m0s5':{'item3line1':[0,0,240,240], 'item30line1':[0,0,248,248], 'item4line1':[0,0,180,180]},
      'grid-s5m0e5':{'item3line1':[0,0,180,180], 'item4line1':[0,0,130,130]},
      'grid-m0s5e5':{'item3line1':[0,0,180,180], 'item4line1':[0,0,130,130]},
      'grid-s5e5m0':{'item3line1':[0,0,180,180], 'item4line1':[0,0,130,130]},
      'grid-e5s5m0':{'item3line1':[0,0,180,180], 'item4line1':[0,0,130,130]},
      'grid-e5m0s5':{'item3line1':[0,0,180,180], 'item4line1':[0,0,130,130]},
      'grid-m0e5s5':{'item3line1':[0,0,180,180], 'item4line1':[0,0,130,130]},
      'col-sub':{'item1line1':[0,0,180,180]},
      'col-extra':{'item1line1':[0,0,180,180]}
    };
     // ��Ϣ�Ĵ���
        function Msg(elem) {
            this.elem = elem;
        }
        S.mix(Msg.prototype, {
            /*
             *
             * ������Ϣ
             *
             * @param value {String} ��Ϣ����
             * @param h {Boolean} Ĭ�� true, �Զ�����
             * @param type {Boolean} ��ʾ��Ϣ����, success: 1, warn:2 , error��0
             * @return {Boolean} �Ƿ�ɹ�
             *
             * */
            val: function( value, type, h ) {
                if ( S.isString( value ) ) {
                    h =  h === undefined ? true : !!h;
                    D.html(D.get('.text',this.elem),value);
                    this.show( type );
                    if ( h ) this.hide( h );
                }
            },

            loading: function() {
                return this.val( '���ڴ��������Ժ�...', 1, false );
            },

            show: function( type ) {
                var elem = this.elem;
                D.css(elem,'opacity', 1);
                D.removeClass(elem,SUCCESS);
                D.removeClass(elem,WARN);
                D.removeClass(elem,FAILURE);
                D.removeClass( elem,DISAPPEAR );

                if(type == 1){
                    D.addClass(elem,SUCCESS);
                }else if(type == 2){
                    D.addClass(elem,WARN);
                }else if(type == 0){
                    D.addClass(elem,FAILURE);
                }
            },

            /*
             * ����
             *
             * @param b {Boolean} �Ƿ���ʱ����, Ĭ��false
             * */
            hide: function( b ) {
                var self = this,
                    elem = self.elem;
                if ( true === b ) {
                    // ���ӳ���, ���¿�ʼ
                    if ( self.timer ) {
                        self.timer.cancel();
                    }
                    self.timer = S.later(function() {
                        var p = { opacity: 0 },
                            a = new S.Anim( elem, p, 0.5 ,'easeIn',function() {
                                D.addClass(elem,DISAPPEAR);
                                self.timer = null;
                            });
                        a.run();
                    }, 3000);
                    return;
                }

                D.addClass(elem,DISAPPEAR);
            }
        });
    function TshopPbsmShopItemRecommend(context){
        var self = this;
        self._mod = context.mod;
        if(!self._mod) return;

        self._init();
    }
    S.augment(TshopPbsmShopItemRecommend,{
        _init: function(){
            S.log("TshopPbsmShopItemRecommend init start");
            var self = this;
            self._updateToken();
            self._bindEvt();
            self.fixHover([{selector:'.item-wrap',hClass:'item-wrap-hover'}]);
            self._initItemRates();
            self._fixMinMax();
            S.log("TshopPbsmShopItemRecommend init end");
        },
        _updateToken: function(){
            var self = this,
                tokenField = D.get("#J_TokenField");
            if(!tokenField) {
              return
            }
            var REG_TOKEN = /_tb_token_=[^&].*/i,
                curToken = "_tb_token_=" + tokenField.value,
                collectItems = D.query(".J_TCollectItem", self._mod);

            S.each(collectItems, function(item) {
                  var curHref = D.attr(item, "data-href");
                  if(REG_TOKEN.test(curHref)) {
                    D.attr(item, "data-href", curHref.replace(REG_TOKEN, curToken))
                  }else {
                    D.attr(item, "data-href", curHref += (curHref.lastIndexOf("&") !== -1 ? "&" : "?") + curToken)
                  }
            })
        },
        _bindEvt: function(){
            var self = this;
//            self._bindItemCollectEvt();
        },
        fixHover: function(hSelectors){
            var self = this,
                elems = [];
            S.each(hSelectors, function(hSelector) {

                elems = D.query(hSelector.selector,self._mod);

                S.each(elems, function(elem) {
                    E.on(elem,'mouseenter', function(e) {
                        S.one(this).addClass(hSelector.hClass);
                    });

                    E.on(elem,'mouseleave', function(e) {
                        S.one(this).removeClass(hSelector.hClass);
                    });
                });
            });
        },
        _bindItemCollectEvt: function(){
            var self = this,
                 itemList = D.get('.items',self._mod);

            E.on(itemList,'click', function(e){
                 var t = e.target;   //��ǰʱ�����������
                 if(D.hasClass(t,'J_TCollectItem')) {
                     var collectN = t;     // �ղؽڵ�
                     S.io({
                       url: D.attr(collectN,'data-href'),
                       data: {
                           "itemSkuList": D.attr(collectN,'data-item-id')
                       },
                       dataType: 'jsonp',
                       success: function(resp) {
                           var msgText,type;
                           if(resp.result.status){
                               // ��ʾ�ղسɹ�
                               msgText = '�ղسɹ�';
                               type = 1;
                           }else{
                               switch (resp.result.message.errorCode) {
                                    //�ղؼ�����
                                    case 7:
                                   // ���ղظñ���
                                    case 8:
                                   // �����ղ���������100��
                                    case 11:
                                        type = 2;
                                        break;
                                    default:
                                        type = 0;
                               }
                               msgText = resp.result.message.error;
                           }
                           var msg = new Msg(D.get('.J_TMsg',D.parent(collectN)));
                               msg.val(msgText, type);
                       },
                       error: function(resp) {
                            var msg = new Msg(D.get('.J_TMsg',D.parent(collectN)));
                               msg.val('������ʱ', 0);
                       }
                    });
                 }
            })
        }
        ,_initItemRates: function(){
            var self = this,
                itemRatesUrlNode = D.get('.J_TItemRatesUrl', self._mod);

            if(itemRatesUrlNode && itemRatesUrlNode.value != ''){             // ������ҹ�ѡ�����۲������۷�������
                // �����۷����첽��������ȡ����������
                S.io({
                   url: itemRatesUrlNode.value,
                   dataType: 'jsonp',
                   jsonp: 'jsoncallback',
                   type: 'post',
                   success: function(resp) {
                       var rateList = resp.batchQueryRateList
                           ,items = D.query('.item', self._mod)
                           ,itemId
                           ,itemRateNode;
                       S.each(items, function(item){
                           itemId = D.attr(item, 'data-id');
                           for (var i = 0; i< rateList.length; i++){
                               if(rateList[i].auctionNumId == itemId){
                                   itemRateNode = D.get('.J_TRate',item);
                                   if(rateList[i].rateContent == ""){
                                       D.text(itemRateNode, "��������");
                                   }else{
                                       D.text(itemRateNode, filterValWithMaxLen(rateList[i].rateContent, 72));
                                   }

                               }
                           }
                       })
                   },
                   error: function(resp) {
                        S.log('��ѯ��������ʧ��');
                   }
                });
            }
        }
        ,_fixMinMax: function(){
          var self = this,
              layer1, layer2;
          var i;
          if(D.parent(self._mod, '.col-sub') != null){
              layer1 = MINMAX_CONFIG['col-sub'];

          }else if(D.parent(self._mod, '.col-extra') != null){
              layer1 = MINMAX_CONFIG['col-extra'];

          }else{
            var layout = D.parent(self._mod, '.layout'),
                layouts = ['grid-m','grid-m0','grid-s5m0','grid-m0s5','grid-s5m0e5','grid-m0s5e5','grid-s5e5m0','grid-e5s5m0','grid-e5m0s5','grid-m0e5s5'];
            for(i = 0, l = layouts.length; i < l; i++){
              if(D.hasClass(layout, layouts[i]))
                break;
            }
            layer1 = MINMAX_CONFIG[layouts[i]];
          }
          var lines = ['item1line1','item3line1','item30line1','item4line1','item5line1','item7line1'];
          var itemLine = D.get('div',D.get('.skin-box-bd',self._mod));
          for(i = 0, l = lines.length; i < l; i++ ){
              if(D.hasClass(itemLine, '.' + lines[i])){
                  break;
              }
          }
          layer2 = layer1[lines[i]];
            if(layer2 == undefined){   // i == lines.length ���߻�ȡ��lines������Ӧlayer1��
                return;
            }
          var limit = layer2,
              elem = D.query('img', self._mod),
              config = {},
              MAP = ['minWidth','minHeight','maxWidth','maxHeight'];
          for(i = 0, l = limit.length; i < l; i++){   //?????????????????
            if(parseInt(limit[i]) !== 0){
              config[MAP[i]] = true;
              config[MAP[i] + 'Value'] = parseInt(limit[i]);
            }
          }
          S.each(elem, function(item){
            new Compatible(item,config);
          });

        }

    });

    /**
    * �������ַ����ȵ�����
    * @param val
    * @param maxlength
    */
    function filterValWithMaxLen(val, maxlength){
        var lenE = val.length,    // �����ַ�����
             lenC = 0,              // �������ĺ�������
             CJK = val.match(/[\u4E00-\u9FA5\uF900-\uFA2D]/g);
        if (CJK != null) lenC += CJK.length;
        var surplus = maxlength - lenE - lenC;
        if(surplus < 0) {
            var tmp = 0,
                 cut = val.substring(0, maxlength);
            for (var i = 0; i < cut.length; i++){
                tmp += /[\u4E00-\u9FA5\uF900-\uFA2D]/.test(cut.charAt(i)) ? 2 : 1;
                if (tmp > maxlength) break;
            }
            return  cut.substring(0, i) + "��";
        }
        return val;
    }
    TshopPbsmShopItemRecommend.selector = '.tshop-pbsm-shop-item-recommend';
    return TshopPbsmShopItemRecommend;
},{requires:['core','../widget/compatible']});
