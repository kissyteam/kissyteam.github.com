KISSY.add(function(S,Core){
    var S = KISSY, E = S.Event, D = S.DOM;
    /**
     * ģ��??
     * @param context
     */
    function TshopPbsmShopItemCates(context){
        var self = this;
        self._mod = context.mod;
        if(!self._mod) return;

        self._init();
    }
     S.augment(TshopPbsmShopItemCates,{
        _init: function(){
            S.log("TshopPbsmShopItemCates init start");
            var self = this;
            self._catHighlight();
            self._bindEvt();
            // ���౻hover
            fixHover([{selector:'.cat-hd',hClass:'.cat-hd-hover'}],self._mod);
            S.log("TshopPbsmShopItemCates init end");
        },
         _catHighlight: function(){
            // ����������ʾ�����ݺ����ҳ��������Ĺ��ڵ�ǰѡ�в˵������Ϣ������Ӧ�Ĳ˵�����и�����ʾ
            var selectedMenuInfo = D.get('#J_TSelectedMenuInfo');
            if(selectedMenuInfo){
                var selectedMenu = S.JSON.parse(D.val(selectedMenuInfo)).selectedMenu,
                    menus = D.query('.cat-hd', self._mod),
                    preSelectedMenu = D.get('.cat-selected', self._mod);

                if(preSelectedMenu){
                    D.removeClass(preSelectedMenu,'cat-selected');
                }
                if(selectedMenu.childCatId==''||selectedMenu.catId==''){
                    return;
                }
                 if(selectedMenu.childCatId==selectedMenu.catId){
                     for(var i= 0; i < menus.length; i++){
                         if(D.attr(menus[i], 'data-cat-id') == selectedMenu.catId){
                             D.addClass(menus[i], 'cat-selected');
                             break;
                         }
                     }
                 }
                 else {
                         for(var i= 0; i < menus.length; i++){
                             if(D.attr(menus[i], 'data-cat-id') == selectedMenu.childCatId){
                                 D.addClass(menus[i], 'cat-selected');
                                 break;
                             }
                         }
                 }
            }
        },
        _bindEvt: function(){
            E.on('.cat-name','click',function(e){
                 var t = D.get(e.currentTarget),  // ?????
                     catHd = D.parent(t, '.cat-hd'),
                     selectedCat = D.get('.cat-selected',self._mod);
                 if(selectedCat)
                     D.removeClass(selectedCat,'cat-selected');
                 if(catHd && !D.hasClass(catHd,'cat-selected'))
                    D.addClass(catHd,'cat-selected');
            });
        }
    });
    function fixHover(hSelectors, container){
        var elems = [],
            IE = S.UA.ie;
        if ( IE && 6 === IE ){
            S.each(hSelectors, function(hSelector) {
                elems = D.query(hSelector.selector,container);

                S.each(elems, function(elem) {
                    E.on(elem,'mouseenter', function(e) {
                        D.addClass(this,hSelector.hClass);

                    });

                    E.on(elem,'mouseleave', function(e) {
                        D.removeClass(this,hSelector.hClass);
                    });
                });
            });
        }
    }
    TshopPbsmShopItemCates.selector = '.tshop-pbsm-shop-item-cates';
    return TshopPbsmShopItemCates;
},{requires:['core']});
