/**
 * @fileOverview hello
 * @author shuier<shuier@taobao.com>
 * @requires ���������˵��
 */

KISSY.add(function(S, Core) {
    var doc = document,D = S.DOM, E = S.Event;
    /**
     * @constructor
     * @param context {object}
     */
    function Hello(context) {
        var self = this;
        self._mod = context.mod;
        if (!self._mod) return;
        self._init();
    }

    S.augment(Hello, {
        _init: function() {
            var self = this,
                helloTrigger = D.get('.J_THelloTrigger',self._mod);
            E.on(helloTrigger,'mouseenter',function(e){
                alert("Hello my dear customer");
            });
        }
    })
	Hello.selector = '.tshop-pbsm-shop-hello'
	return Hello;
}, {requires:['core']});