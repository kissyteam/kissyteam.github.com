KISSY.add(function(S,Core,Overlay,Compatible){
    var S = KISSY, E = S.Event, D = S.DOM;
    function TshopPbsmShopNavCh(context){
        var self = this;
        self._mod = context.mod;
        if(!self._mod) return;

        self._init();
    }
    S.augment(TshopPbsmShopNavCh,{
        _init: function(){
            S.log("TshopPbsmShopNavCh init start");
           var self = this;
           self._menuHighlight();
            S.ready(function(){
               self._menuPopup();
               self._bindEvt();
               self._setInherentStyle();
               self._fixMaxHeight();
               fixHover([{selector:'.all-cats',hClass:'all-cats-hover'},{selector:'.fst-cat',hClass:'.cat-hd-hover'},{selector: '.snd-cat-hd', hClass: '.snd-cat-hd-hover'}, {selector:'.menu',hClass:'.menu-hover'},{selector:'.sub-cat',hClass:'.sub-cat-hover'}],D.query('.tshop-pbsm-shop-nav-ch'));
            });
            S.log("TshopPbsmShopNavCh init end");
        },
        /**
         * ˵��??���Ϊ�����Ч�ʣ����ٲ�ѯ�����ʱ�䣬ϣ����ǰ�˰�æ????�������ĸ���
         * {"selectedMenu":{"pageId":"182097", "catId": "" , "linkId":""}
         */
        _menuHighlight: function(){
            // ����������ʾ�����ݺ����ҳ��������Ĺ��ڵ�ǰѡ�в˵������Ϣ������Ӧ�Ĳ˵�����и�����ʾ
            var selectedMenuInfo =   D.get('#J_TSelectedMenuInfo');
            if(selectedMenuInfo){
                var selectedMenu = S.JSON.parse(D.val(selectedMenuInfo)).selectedMenu,
                    menus = D.query('.menu', self._mod),
                    preSelectedMenu = D.get('.menu-selected', self._mod);

                if(preSelectedMenu){
                    D.removeClass(preSelectedMenu,'menu-selected');
                }
                if(selectedMenu.catId != ""){
                     for(var i= 0; i < menus.length; i++){
                         if(D.attr(menus[i], 'data-cat-id') == selectedMenu.catId){
                             D.addClass(menus[i], 'menu-selected');
                             break;
                         }
                     }
                }else if(selectedMenu.pageId != ""){
                    for(var i= 0; i < menus.length; i++){
                         if(D.attr(menus[i], 'data-page-id') == selectedMenu.pageId){
                             D.addClass(menus[i], 'menu-selected');
                             break;
                         }
                     }
                }else if(selectedMenu.linkId != ""){
                     for(var i= 0; i < menus.length; i++){
                         if(D.attr(menus[i], 'data-link-id') == selectedMenu.linkId){
                             D.addClass(menus[i], 'menu-selected');
                             break;
                         }
                     }
                }
            }
        },
        _menuPopup: function(){
            //Ϊ�˱�֤#hdҳͷ 150px�ĸ߶ȣ����������Ƶ�body���Ѱ

            var popDiv = D.create("<div class='skin-box-bd'></div>");
            var pop = D.create("<div class='tshop-pbsm-shop-nav-ch'></div> ");
            D.append(popDiv,pop);
            D.append(pop,'#content');
            D.css(popDiv,"width","0");
            D.css(popDiv,"height","0");

            // �½�����˵�����??
            // ע�⣺ʹ�ö��Ƶ���ʾ/���ط�ʽ
            var popupTriggers = D.query('.popup-trigger',self._mod);
            S.each(popupTriggers,function(popupTrigger) {
                var container = D.parent(popupTrigger, '.popup-container');
                var curPop = D.get('.popup-content', container);
                D.append(curPop, popDiv);
                var popupContent = curPop;

                new Overlay.Popup({
                     srcNode:popupContent,
                     trigger: popupTrigger,
                     triggerType: 'mouse',
                     //width: container.offsetWidth-2,    // outerWidth 1.1.6��֧?? , ��ԭ����offsetWidth, offsetWidth = width + padding + border
                     align: {
                         node: container,
                         points: ['bl','tl'],
                         offset: [0,0]
                     },
                     /*effect:{
                        effect:'slide',    // {String} - ��??, Ĭ��??none', 'none'(����??, 'fade'(������ʾ), 'slide'(������ʾ).
                        easing:'easeNone',        // {String} - ��??, ??KISSY.Anim ??easing ��������.
                        duration: 0.3     // {Number} - ��??, ��������ʱ��, ����Ϊ��??
                     },*/
                     zIndex: 1e8          // ϵͳpopup�����z-index��Χ?99999999 �� ��99999999 + 100��
                });
            });

            // ????������۵�չ??


            var fstCatHds = D.query('.fst-cat-hd', popDiv);

            S.each(fstCatHds, function(fstCatHd) {
               // var container = D.parent(fstCatHd,'.popup-container');
                new Overlay.Popup({
                    srcNode:D.next(fstCatHd,'.snd-pop'),
                    trigger: fstCatHd,
                    triggerType: 'mouse',
                    align: {
                        node: fstCatHd,
                        points: ['tr','tl'],
                        offset: [0,0]
                    },
                    /*effect:{
                        effect:'slide',    // {String} - ��??, Ĭ��??none', 'none'(����??, 'fade'(������ʾ), 'slide'(������ʾ).
                        easing:'easeNone',        // {String} - ��??, ??KISSY.Anim ??easing ��������.
                        duration: 0.3     // {Number} - ��??, ��������ʱ��, ����Ϊ��??
                    },*/
                    zIndex: 1e8             // ϵͳpopup�����z-index��Χ?99999999 �� ��99999999 + 100��
                });
            });
        },
        _bindEvt: function(){

        },
        /**
         * ����????���ȼ��Ƚϸߵ���ʽ��ȷ������ģ��????������ʾ�����Ǹ߶ȿ���Ϊ0
         */
        _setInherentStyle: function(){
            var self = this;
            D.css(self._mod, 'display', 'block');
            D.css(self._mod, 'visibility', 'visible');
        },
        _fixMaxHeight: function(){
            // �����޸�150
            var self = this;
            new Compatible(self._mod,{'maxHeight':true,'maxHeightValue':150});
            // ҳͷ�޸�150
            new Compatible(D.get("#hd"),{'maxHeight':true,'maxHeightValue':150});
            //ie6�µ�����Ҫ��λ����ֱ����ʽstatic�Ļ����ڴ�λ
            D.css('.tshop-pbsm-shop-custom-banner','position','relative');
        }
    });

    function fixHover(hSelectors, container){
        var elems = [];
        S.each(hSelectors, function(hSelector) {
            elems = [];
            container.each(function(subContainer){
                elems.push(D.query(hSelector.selector,subContainer))
            });
           // elems = D.query(hSelector.selector,container);
            S.each(elems, function(elem) {
                E.on(elem,'mouseenter', function(e) {
                    D.addClass(this,hSelector.hClass);

                });

                E.on(elem,'mouseleave', function(e) {
                    D.removeClass(this,hSelector.hClass);
                });
            });
        });
    }
    TshopPbsmShopNavCh.selector = '.tshop-pbsm-shop-nav-ch';
    return TshopPbsmShopNavCh;
},{requires:['core','overlay','../widget/compatible']});