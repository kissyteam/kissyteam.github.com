<!doctype html>
<html>
<head>
    <meta charset="gbk"/>
    <meta name="keywords" content="�Ա�, ����, ����, ������"/>
    <meta name="description" content="��ӭǰ���Ա���ĳĳ���̣�ѡ��ĳĳ��Ʒ,���˽����ĳĳ��Ʒ�������ĳĳ���̣��ڶ���Ʒ����ѡ��"/>
    <title>��ҳ-c�����˺�152����-test-����/�������/����- �Ա��� </title>
    <script>
        window.g_hb_monitor_st = +new Date();
        window.g_config = {appId: 2, assetsHost: "http://assets.daily.taobao.net", toolbar: false, pageType: "wangpu"};
        window.shop_config = {};
        window.shop_config.mods = ["header", "custom-banner", "nav", "item-cates", "item-recommend"];
    </script>
    <link rel="shortcut icon" href="http://www.taobao.com/favicon.ico" type="image/x-icon"/>
    <link rel="stylesheet" href="http://a.tbcdn.cn/??p/global/1.0/global-min.css?t=20120528.css"/>
    <link rel="stylesheet" href="http://assets.daily.taobao.net/apps/taesite/platinum/stylesheet/??view/layout-min.css"/>
    <link rel="stylesheet" href="../../assets/css/skin/default.css"/>
    <link rel="stylesheet" href="../../assets/css/skin/yellow.css"/>
    <script  src="http://assets.daily.taobao.net/??s/kissy/1.3.0/seed-min.js,p/global/1.0/global-min.js?t=20121127.js"></script>
    <script src="../../../build-combo/shop/init.js"></script>
</head>
<body>
<input type="hidden" id="J_TSelectedMenuInfo" value='{"selectedMenu":{"pageId":"1", "catId": "" , "linkId":""}}'>
<input type="hidden" value="21XUxjAl" name="tb_token" id="J_TokenField"/>

<div id="page">
<!-- ϵͳҳͷ -->
<?@include '../mods/header.php'?>
<div id="content" class="tb-shop">
    <div id="hd">
        <div class="layout grid-m0" data-id="5234984" data-prototypeid="1">
            <div class="col-main">
                <div class="main-wrap J_TRegion" data-modules="main" data-width="950">
                    <!-- your mod html goes here -->
                    <?@include '../mods/custom-banner.php'?>
                    <?@include '../mods/nav.php'?>
                </div>
            </div>
        </div>
    </div>
    <div id="bd">
        <div class="layout grid-s5m0" data-id="5022284" data-prototypeid="2">
            <div class="col-main">
                <div class="main-wrap J_TRegion" data-modules="main" data-width="b750">
                    <?@include '../mods/item-recommend.php'?>
                </div>
            </div>
            <div class="col-sub J_TRegion" data-modules="sub" data-width="b190">
                <?@include '../mods/item-cates.php'?>
            </div>
        </div>
    </div>
    <div id="ft">
        <div class="layout grid-m0" data-id="5234984" data-prototypeid="1">
            <div class="col-main">
                <div class="main-wrap J_TRegion" data-modules="main" data-width="950">
                </div>
            </div>
        </div>
    </div>
</div>

</div>

</body>
</html>


