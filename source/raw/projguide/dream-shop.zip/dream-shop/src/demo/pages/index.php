<!doctype html>
<html>
<head>
    <!-- ���head��ǩ���� -->        <!--  Ҫ���������Ҫ���ص�������gbk���� -->
    <meta charset="gbk"/>
    <meta name="keywords" content="�Ա�, ����, ����, ������"/>
    <meta name="description" content="��ӭǰ���Ա���ĳĳ���̣�ѡ��ĳĳ��Ʒ,���˽����ĳĳ��Ʒ�������ĳĳ���̣��ڶ���Ʒ����ѡ��"/>
    <!-- ������� -->
    <!--        <meta name="spm-id" content="1103JYui.1-bbqPC" />-->
    <!-- ҳ����΢��ϵͳҪ��֪�ĵ�ǰҳ��Ķ�����Ϣ -->
    <!--        <meta name="microscope-data" content="pageId=187542758; prototypeId=1; siteId=7; shopId=62375826; userid=436169643;">-->

    <!-- ����title�����,�뿪��������ҳ������\������\��Ӫ��Ŀ\վ������ -->
    <title>��ҳ-c�����˺�152����-test-����/�������/����- �Ա��� </title>

    <!-- ע��λ�ã�Ҫ����������ǩ֮ǰ����meta��title����Ҳ���� Ҫ����script��link��ǩ֮ǰ-->
    <!--  ���ã���IE8��IE7������Ⱦ��ʹ��ҳ��IE8��������ʾ -->
    <meta http-equiv="X-UA-Compatible" content="IE=7"/>

    <!--  g_hb_monitor_st=+new Date();������� -->
    <!--  appId web���� -->
    <!-- link��ǩ script��ǩ������ѭ�µ���ǰ�˹淶 -->
    <script>
        window.g_hb_monitor_st = +new Date();
        // ȫ�����ã� appId(������ƣ�ǰ�����ܼ�ض���Ҫ)
        window.g_config = {appId: 2, assetsHost: "http://assets.daily.taobao.net", toolbar: false, pageType: "wangpu"};
        window.shop_config = {};
        window.shop_config.mods = ["header", "custom-banner", "nav", "item-cates", "item-recommend","hello"];
        window.shop_config.isView = true;
        // ��isvͳ����ص�����
        window.shop_config.isvStat = {
            nickName: '%E7%90%A6%E7%91%9E%E8%8B%9B%E8%8B%9B',
            userId: '628334563',
            shopId: '63717089',
            itemId: '',
            itemNumId: 15812079773,
            shopStats: '0',
            validatorUrl: 'http://store.taobao.com/tadget/shop_stats.htm',
            templateName: '%E6%97%B6%E5%B0%9A%E6%AC%A7%E7%BE%8ESDK-DIY%E6%A8%A1%E6%9D%BF-%E6%9C%8D%E8%A3%85%E9%9E%8B%E5%B8%BD%E7%B2%BE%E5%93%81-%E5%88%9B%E5%AE%A2%E8%AE%BE%E8%AE%A1',
            templateId: '1119412'
        }
        // poc ҳ����
        window._poc = window._poc || [];
        // �Զ������ݣ�������ǰ��õļ�������Ƕ��µ��̵�ҳ����
        _poc.push(["_trackCustom", "tpl", "new_shop"]);
    </script>
    <!--  ��ַ��ͼ��  -->
    <link rel="shortcut icon" href="http://www.taobao.com/favicon.ico" type="image/x-icon"/>

    <!-- �����css��js �ο��µ���ҳ�湹�ɹ淶 -->
    <!-- �Ա�ȫ����ʽ���� reset.css��site-nav.css -->
    <link rel="stylesheet" href="http://a.tbcdn.cn/??p/global/1.0/global-min.css?t=20120528.css"/>

    <!-- ҳ�沼�֣��汾��ҳ����ʽ -->
    <link rel="stylesheet"
          href="http://assets.daily.taobao.net/apps/taesite/platinum/stylesheet/??view/layout-min.css,view/copyright-min.css,view/footer-min.css"/>

    <!-- �ٷ�ģ��Ĭ��Ƥ�� -->
    <link rel="stylesheet" href="../../assets/css/skin/default.css"/>

    <!-- �ٷ���ɫģ�壬��������ϵͳĬ��Ƥ�� -->
    <link rel="stylesheet" href="../../assets/css/skin/yellow.css"/>

    <script
        src="http://assets.daily.taobao.net/??s/kissy/1.3.0/seed-min.js,p/global/1.0/global-min.js?t=20121127.js"></script>

</head>
<body>
<!-- ������������������ǰ�˵���Ϣ -->
<input type="hidden" id="J_TSelectedMenuInfo" value='{"selectedMenu":{"pageId":"1", "catId": "" , "linkId":""}}'>
<!-- ��Ҫtoken��һЩ���� -->
<input type="hidden" value="21XUxjAl" name="tb_token" id="J_TokenField"/>

<div id="page">
<!-- �Ա����� -->
<div id="site-nav">
    <div id="site-nav-bd">
        <p class="login-info">
            <script>
                TB.Global.writeLoginInfo({
                    "memberServer": "http://member1.taobao.com",
                    "outmemServer": "",
                    "loginServer": "https://login.taobao.com",
                    redirectUrl: "",
                    logoutUrl: ""
                });
            </script>
        </p>
        <ul class="quick-menu">
            <li class="home">
                <a href="http://www.taobao.com/">
                    �Ա�����ҳ
                </a>
            </li>
            <li class="menu-item">
                <div class="menu">
                    <a class="menu-hd" style="width:36px;"
                       href="http://ju.atpanel.com/?url=http://love.taobao.com?ad_id=&am_id=&cm_id=&pm_id=15004294216338fc3746"
                       target="_top" rel="nofollow">
                        ��Ҫ��
                        <b>
                        </b>
                    </a>

                    <div class="menu-bd" style="width:82px;height:75px;line-height:1.7;">
                        <div class="menu-bd-panel" style="padding:8px 10px;">
                            <div>
                                <a href="http://ju.atpanel.com/?url=http://list.taobao.com/browse/cat-0.htm?ad_id=&am_id=&cm_id=&pm_id=15006048193468e03af6"
                                   target="_top" rel="nofollow">
                                    ��Ʒ����
                                </a>
                                <a href="http://ju.atpanel.com/?url=http://love.taobao.com/guang/index.htm?ad_id=&am_id=&cm_id=&pm_id=1500604820c8c4721fc4"
                                   target="_top" rel="nofollow">
                                    ���������
                                </a>
                                <a href="http://ju.atpanel.com/?url=http://love.taobao.com/toukui/index.htm?ad_id=&am_id=&cm_id=&pm_id=150060482114b4eabfba"
                                   target="_top" rel="nofollow">
                                    Ʒζ������
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </li>
            <li class="mytaobao menu-item">
                <div class="menu">
                    <a class="menu-hd" href="http://i.taobao.com/my_taobao.htm" target="_top"
                       rel="nofollow">
                        �ҵ��Ա�
                        <b>
                        </b>
                    </a>

                    <div class="menu-bd" style="height: 75px;">
                        <div class="menu-bd-panel" id="myTaobaoPanel">
                            <div>
                                <a href="http://trade.taobao.com/trade/itemlist/list_bought_items.htm"
                                   target="_top" rel="nofollow">
                                    ���򵽵ı���
                                </a>
                            </div>
                            <div>
                                <a href="http://jianghu.taobao.com/admin/invite/invite_friend.htm" target="_top"
                                   rel="nofollow">
                                    �ҵĺ���
                                </a>
                            </div>
                            <div>
                                <a href="http://i.taobao.com/my_taobao.htm" target="_top" rel="nofollow">
                                    ���¶�̬
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </li>
            <style>
                #site-nav .seller-center .menu-hd {
                    width: 48px;
                }

                #site-nav .seller-center
                .menu-bd {
                    width: 94px;
                    line-height: 1.7;
                }

                #site-nav .seller-center .menu-bd-panel {
                    padding: 8px 10px;
                }
            </style>
            <li class="seller-center menu-item">
                <div class="menu">
                    <a class="menu-hd" href="http://mai.taobao.com/seller_admin.htm" target="_top"
                       rel="nofollow">
                        ��������
                        <b>
                        </b>
                    </a>

                    <div class="menu-bd">
                        <div class="menu-bd-panel">
                            <div>
                                <a href="http://trade.taobao.com/trade/itemlist/list_sold_items.htm" target="_top"
                                   rel="nofollow">
                                    �������ı���
                                </a>
                                <a href="http://sell.taobao.com/auction/goods/goods_on_sale.htm" target="_top"
                                   rel="nofollow">
                                    �����еı���
                                </a>
                                <a href="http://daxue.taobao.com/?spm=261.1.1024.1024" target="_top" rel="nofollow">
                                    �Ա���ѧ
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </li>
            <li class="service">
                <a href="http://service.taobao.com/support/main/service_center.htm" target="_top"
                   rel="nofollow">
                    ��������
                </a>
            </li>
            <li class="cart">
                <a href="http://cart.taobao.com/my_cart.htm" target="_top" rel="nofollow">
                    <s>
                    </s>
                    ���ﳵ
                </a>
            </li>
            <li class="favorite menu-item">
                <div class="menu">
                    <a class="menu-hd" style="width:36px;"
                       href="http://favorite.taobao.com/collect_list-1-.htm?scjjc=c1"
                       target="_top" rel="nofollow">
                        �ղؼ�
                        <b>
                        </b>
                    </a>

                    <div class="menu-bd" style="width:82px;height:57px;line-height:1.7;">
                        <div class="menu-bd-panel" style="padding:8px 10px;">
                            <div>
                                <a href="http://favorite.taobao.com/collect_list.htm?itemtype=1" target="_top"
                                   rel="nofollow">
                                    �ղصı���
                                </a>
                                <a href="http://favorite.taobao.com/collect_list.htm?itemtype=0" target="_top"
                                   rel="nofollow">
                                    �ղصĵ���
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </li>
            <li class="services menu-item last">
                <div id="J_Service" class="menu">
                    <a class="menu-hd" href="http://www.taobao.com/sitemap.php?id=sitemap2"
                       target="_top">
                        ��վ����
                        <b>
                        </b>
                    </a>

                    <div id="J_ServicesContainer" class="menu-bd"
                         style="width:202px;width:210px\9;_width:202px;height:337px;">
                    </div>
                </div>
            </li>
        </ul>
    </div>
</div>
<!-- system-announce -->
<!-- end vmc 3.1 -->
<script>
    TB.Global.init();
</script>
<!-- ϵͳҳͷ -->
<?@include '../mods/header.php'?>
<div id="content" class="tb-shop">
    <div id="hd">
        <div class="layout grid-m0" data-id="5234984" data-prototypeid="1">
            <div class="col-main">
                <div class="main-wrap J_TRegion" data-modules="main" data-width="950">
                    <?@include '../mods/custom-banner.php'?>
                    <?@include '../mods/nav.php'?>
                </div>
            </div>
        </div>
    </div>
    <div id="bd">
        <div class="layout grid-s5m0" data-id="5022284" data-prototypeid="2">
            <div class="col-main">
                <div class="main-wrap J_TRegion" data-modules="main" data-width="b750">
                    <?@include '../mods/item-recommend.php'?>
                    <?@include '../mods/hello.php'?>
                </div>
            </div>
            <div class="col-sub J_TRegion" data-modules="sub" data-width="b190">
                <?@include '../mods/item-cates.php'?>
            </div>
        </div>
    </div>
    <div id="ft">
        <div class="layout grid-m0" data-id="5234984" data-prototypeid="1">
            <div class="col-main">
                <div class="main-wrap J_TRegion" data-modules="main" data-width="950">
                </div>
            </div>
        </div>
    </div>
</div>

<div id="copyright">
    <div class="shop-info"> <!--206531,0-->
        <a href="http://wangpu.taobao.com/wangpu/comparation.htm" class="version" target="_blank">
            <img alt="2012�°�����" src="http://img01.taobaocdn.com/tps/i1/T1lKXaXp4hXXcgU5U6-113-21.png ">
        </a>
    </div>
    <p style="display:none;" class="J_TShowForSeller">
        <br>
        <a target="_blank" href="http://bbs.taobao.com/catalog/thread/510526-260489426.htm">
            <img src="http://img03.taobaocdn.com/tps/i3/T1iKNsXxpfXXa4..bi-950-90.png">
        </a>
    </p>
</div>
<div id="footer">
<div class="g_foot">
    <div class="g_foot-ali">
        <a href="http://page.china.alibaba.com/shtml/about/ali_group1.shtml">����Ͱͼ���</a> <b>|</b>
        <a class="g_foot-nohover" target="_self" href="javascript:void(0)">����Ͱ����磺</a>
        <a href="http://www.alibaba.com/">����վ</a>
        <a href="http://china.alibaba.com/">����վ</a>
        <a href="http://mai.aliexpress.com/">ȫ������ͨ</a> <b>|</b>
        <a href="http://www.taobao.com/?id=shouye_taobao">�Ա���</a>
        <b>|</b>
        <a href="http://www.tmall.com/">��è</a>
        <b>|</b>
        <a href="http://www.etao.com/">һ��</a>
        <b>|</b>
        <a href="http://www.aliyun.com/">������</a>
        <b>|</b>
        <a href="http://www.yahoo.com.cn/">�й��Ż�</a>
        <b>|</b>
        <a href="http://www.alipay.com/">֧����</a>
        <b>|</b>
        <a href="http://ju.taobao.com/">�ۻ���</a>
        <b>|</b>
        <span id="J_FooterMore" class="footer-more">
          <span class="footer-more-panel">
            <a href="http://www.aliresearch.com/">�����о�</a><br>
            <a href="http://www.alihz.com/">�����չ</a><br>
            <a href="http://www.hitao.com/">������</a><br>
          </span>
          <a class="footer-more-trigger" target="_self" href="javascript:void(0);">���� <s class="arrow arrow-d"></s></a>
        </span>
    </div>
    <div class="g_foot-nav">
        <a href="http://www.taobao.com/about/">�����Ա�</a>
        <a href="http://www.taobao.com/about/partners.php">�������</a>
        <a href="http://pro.taobao.com/">Ӫ������</a>
        <a href="http://service.taobao.com/support/main/service_route.htm">��ϵ�ͷ�</a>
        <a href="http://open.taobao.com/">����ƽ̨</a>
        <a href="http://www.taobao.com/about/join.php">����Ӣ��</a>
        <a href="http://www.taobao.com/about/contact.php">��ϵ����</a>
        <a href="http://www.taobao.com/sitemap.php">��վ��ͼ</a>
        <a href="http://www.taobao.com/about/copyright.php">��������</a>
        <span>&copy; 2013 Taobao.com ��Ȩ����</span>
    </div>
    <span class="g_foot-toy"></span>
    <span class="g_foot-line"></span>
</div>
<script>
    // hover effect for ie6
    (function () {

        if (-[1, ]) return;

        var ie6FootHover = document.getElementById("J_FooterMore");

        ie6FootHover.onmouseenter = function () {
            this.className += " footer-more-hover";
        }
        ie6FootHover.onmouseleave = function () {
            this.className = this.className.replace(new RegExp(" footer-more-hover\\b"), "");
        }
    })();


</script>

<style>
    .g_foot {
        width: 960px;
        margin: 0 auto;
        font: 12px / 1.5 tahoma, arial, �� �� b8b\4f53;
        padding: 7px 0 9px;
        color: #b0b0b0;
        text-align: left !important;
        position: relative;
        clear: both;
    }

    .g_foot a {
        margin: 0 4px;
        color: #3e3e3e;
        text-decoration: none;
    }

    .g_foot a:hover {
        color: #F60;
        text-decoration: underline;

    }

    .g_foot-ali {
        margin-right: 100px;
        padding-left: 0;
        border-bottom: 1px solid #D3D3D3;
        padding-bottom: 8px;
        height: 18px;
    }

    .g_foot-nohover {
        cursor: default;
    }

    .g_foot-nohover:hover {
        color: #3e3e3e !important;
        text-decoration: none !important;
    }

    .g_foot-ali a, .g_foot-ali b {
        float: left;

    }

    .g_foot-ali b {
        margin: 0 4px;
        color: #d3d3d3;
        font-weight: normal;
        *margin-top: -1px;
        margin-top: -1px   \0/;
    }

    .g_foot-nav {
        margin-top: 8px;
        line-height: 20px;
    }

    .g_foot-nav span {
        margin-left: 50px;
    }

    .g_foot-toy {
        position: absolute;
        background: url(http://img01.taobaocdn.com/tps/i1/T1MMPaXkNjXXaXezbh-48-70.png) no-repeat;
        _background: url(http://img01.taobaocdn.com/tps/i1/T1XgzaXX0kXXaXezbh-48-70.png) no-repeat;
        width: 69px;
        height: 100px;
        display: block;
        right: 0px;
        top: 0px;
    }

        /* IE9 only */
    :root .g_foot-toy {
        right: -20 px\9;
    }

    .g_foot-line {
        display: none;
        position: absolute;
        background: url(http://img01.taobaocdn.com/tps/i1/T1I_56Xl0wXXXXXXXX-104-1.png) no-repeat;
        width: 104px;
        height: 1px;
        right: 45px;
        top: 33px;
    }

    .footer-more {
        cursor: pointer;
        z-index: 1;
        position: relative;
        padding-top: 1px;
        width: 82px;
        float: left;
        *top: -1px;
        top: -2px   \0/;

    }

    .footer-more-trigger {
        position: absolute;

        padding: 6px 11px 4px 14px;
        width: 37px;
        line-height: 1.3;
        border: 1px solid #fff;
        left: -12px;
        top: -5px;
    }

    .footer-more-trigger .arrow {
        position: absolute;
        display: inline-block;
        font-size: 0;
        line-height: 0;
        width: 0;
        height: 0;
        border: dashed 4px;
    }

    .footer-more-trigger .arrow-d {
        border-color: #666 transparent transparent transparent;
        border-top-style: solid;
        right: 12px;
        top: 11px;
    }

    .footer-more-panel {
        text-align: left;
        position: absolute;
        right: 26px;
        bottom: -90px;
        padding: 7px 3px 2px 2px;
        border: 1px solid #C5C5C5;
        width: 57px;
        background: white;
        line-height: 1.9;
        display: none;
    }

    .footer-more-panel a {
        float: none;
        margin-right: 3px;
    }

    .footer-more-hover .footer-more-trigger, .footer-more:hover .footer-more-trigger {
        border-color: #c5c5c5;
        background: #fff;
        border-bottom: 0;
    }

    .footer-more-hover .footer-more-panel, .footer-more:hover .footer-more-panel {
        display: block;
    }

    .footer-more-hover .footer-more-trigger .arrow-d, .footer-more:hover .footer-more-trigger .arrow-d {
        -moz-transform: rotate(180deg);
        -moz-transform-origin: 50% 30%;
        -o-transform: rotate(180deg);
        -o-transform-origin: 50% 30%;
        -webkit-transform: rotate(180deg);
        -webkit-transform-origin: 50% 30%;
        transform: rotate(180deg);
        transform-origin: 50% 30%;
        filter: progid:DXImageTransform.Microsoft.BasicImage(rotation = 2);
        *top: 8px;
        top: 8px   \0/;
    }
</style>
<div id="server-num">shopsystem169182.cm4</div>
</div>

</div>

<script src="../../../build-combo/shop/init.js"></script>

</body>
</html>


