<div class="J_TModule" id="shop11">
    <div class="skin-box tb-module tshop-pbsm tshop-pbsm-shop-custom-banner" style="height:120px;">
        <s class="skin-box-tp"><b></b></s>
        <!-- ����head���� -->
        <div class="skin-box-hd disappear">
            <i class="hd-icon"></i>

            <h3><span>���</span></h3>

            <div class="skin-box-act">
                <a class="more" href="#">����</a>
            </div>
        </div>
        <!-- �������岿�� -->
        <div class="skin-box-bd">
            <style>.tshop-pbsm-shop-custom-banner .banner-box {
                    background: url(xxx.jpg) repeat 0 0;
                    height: 110px;
                }</style>
            <div>
                <div class="banner-box">
                    <!--
                    <a href="#" title="" alt="" class="banner-img-box"><img src="http://demo.ued.taobao.net/yumen/images/950x150.png" /></a>
                    -->
                </div>
            </div>
            <h2 class="title border-radius">�߸���ħ��</h2>

        </div>
        <s class="skin-box-bt"><b></b></s>

    </div>
</div>