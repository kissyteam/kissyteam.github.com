KISSY.add("shop/mods/header", function(S, Core, Cookie, Suggest, Overlay, Compatible) {
  var S = KISSY, E = S.Event, D = S.DOM, C = S.Cookie, ie = document.all, win = window, doc = document, UA = S.UA, $ = S.Node.all;
  var DataStore = {create:function() {
    if(typeof localStorage !== "undefined") {
      oStorage = localStorage
    }else {
      if(ie) {
        oStorage = doc.createElement("input");
        oStorage.type = "hidden";
        doc.body.appendChild(oStorage);
        oStorage.addBehavior("#default#userData")
      }
    }
  }, set:function(key, value) {
    if("setItem" in oStorage) {
      oStorage.setItem(key, value)
    }else {
      if(ie) {
        try {
          oStorage.setAttribute(key, value);
          oStorage.save("IELocalDataStore")
        }catch(e) {
        }
      }
    }
  }, get:function(key) {
    if("getItem" in oStorage) {
      return oStorage.getItem(key)
    }else {
      if(ie) {
        try {
          oStorage.load("IELocalDataStore");
          return oStorage.getAttribute(key)
        }catch(e) {
        }
      }
    }
  }};
  function TshopPsmShopHeader(context) {
    var self = this;
    self._mod = context.mod;
    if(!self._mod) {
      return
    }
    self._init()
  }
  S.augment(TshopPsmShopHeader, {_init:function() {
    S.log("TshopPsmShopHeader init start");
    var self = this;
    self._bindHasLongHoverEvt();
    self._initArchive();
    self._initQS();
    self._initSearch();
    self._initCustomerService();
    self._initCollect();
    S.log("TshopPsmShopHeader init end")
  }, _bindHasLongHoverEvt:function() {
    var self = this, hasHoverEls = D.query(".has-hover", self._mod);
    S.each(hasHoverEls, function(hasHoverEl) {
      var mouseEnterTimer, mouseLeaveTimer;
      E.on(hasHoverEl, "mouseenter", function(e) {
        var t = e.currentTarget;
        var popupContent = D.get(".popup-content", t);
        D.addClass(t, "hover");
        if(mouseEnterTimer) {
          mouseEnterTimer.cancel()
        }
        mouseEnterTimer = S.later(function() {
          D.addClass(t, "long-hover");
          D.addClass(D.prev(t), "next-sibling-hover");
          D.removeClass(popupContent, "hide");
          self._computeSeparatorsHeight(popupContent);
          self._computerQualificationServiceWidth(popupContent);
          E.on(popupContent, "mouseover", function() {
            if(mouseLeaveTimer) {
              mouseLeaveTimer.cancel()
            }
          });
          mouseEnterTimer.cancel()
        }, 0);
        var popHover;
        if(D.hasClass(t, "next-sibling-hover")) {
          popHover = D.next(t)
        }else {
          if(D.hasClass(D.prev(t), "hover")) {
            popHover = D.prev(t)
          }
        }
        if(popHover) {
          D.removeClass(popHover, "hover");
          D.removeClass(popHover, "long-hover");
          D.removeClass(D.prev(popHover), "next-sibling-hover");
          D.addClass(D.get(".popup-content", popHover), "hide")
        }
      });
      E.on(hasHoverEl, "mouseleave", function(e) {
        var t = e.currentTarget;
        var popupContent = D.get(".popup-content", t);
        if(mouseLeaveTimer) {
          mouseLeaveTimer.cancel()
        }
        mouseLeaveTimer = S.later(function() {
          D.removeClass(t, "hover");
          D.removeClass(t, "long-hover");
          D.removeClass(D.prev(t), "next-sibling-hover");
          D.addClass(popupContent, "hide");
          mouseLeaveTimer.cancel()
        }, 300)
      })
    })
  }, _computeSeparatorsHeight:function(popupContent) {
    var self = this, separators = D.query(".vertical-separator", popupContent), contentLeftH = 0, contentRightH = 0;
    S.each(separators, function(separator) {
      contentLeftH = D.prev(separator) ? D.prev(separator).offsetHeight : 0;
      contentRightH = D.next(separator) ? D.next(separator).offsetHeight : 0;
      D.height(separator, contentLeftH > contentRightH ? contentLeftH : contentRightH)
    })
  }, _computerQualificationServiceWidth:function(popupContent) {
    var self = this, bdLeft = D.query(".qualification", popupContent), bdRight = D.query(".service", popupContent), qualificationService = D.parent(bdLeft, ".popup-content") || D.parent(bdRight, ".popup-content");
    if(bdLeft.length && bdRight.length) {
      D.width(qualificationService, "501px")
    }
  }, _initSearch:function() {
    var self = this, form = D.get("#J_TShopSearchForm", self._mod), searchInput = D.get("#shop-q", form);
    self._getSearchWidth(searchInput);
    self._bindSearchEvt(form, searchInput);
    S.ready(function() {
      self._handleSearchMonitor()
    })
  }, _getSearchWidth:function(searchInput) {
    var self = this, logo = D.get(".logo", self._mod), ha = D.get(".head-archives", self._mod), qs = D.get(".qualification-service", self._mod), favorites = D.get(".favorites", self._mod), cs = D.get(".customer-service", self._mod);
    if(!(logo && ha && qs && favorites && cs)) {
      return
    }
    var tmp = 0;
    if(qs != null) {
      tmp = qs.offsetWidth
    }
    var searchWidth = 950 - logo.offsetWidth - ha.offsetWidth - tmp - favorites.offsetWidth - cs.offsetWidth;
    D.css(searchInput, {width:searchWidth - 25})
  }, _bindSearchEvt:function(form, searchInput) {
    var self = this;
    E.on(form, "mouseenter", function(e) {
      var t = e.currentTarget;
      D.addClass(t, "form-hover")
    });
    E.on(form, "mouseleave", function(e) {
      var t = e.currentTarget;
      D.removeClass(t, "form-hover")
    });
    self._searchInputHit(searchInput);
    var sug = new S.Suggest(searchInput, "http://suggest.taobao.com/sug?code=utf-8", {resultFormat:"\u053c%result%\ufffd\ufffd\ufffd\ufffd\ufffd\ufffd", offset:-2});
    E.on(".search-button", "click", function(evt) {
      var curBtn = this;
      form.action = D.hasClass(curBtn, "searchtb") ? D.attr(form, "action") : D.attr(curBtn, "data-action");
      form.submit()
    })
  }, _searchInputHit:function(searchInput) {
    if(!searchInput) {
      return
    }
    var elemParent = searchInput.parentNode, FORMFOCUS = "form-focus", BUTTONSWIDTH = 100, blurHandle = function() {
      "" !== searchInput.value ? D.addClass(elemParent, FORMFOCUS) : D.removeClass(elemParent, FORMFOCUS)
    };
    E.on(searchInput, "focus", function(e) {
      D.addClass(elemParent, FORMFOCUS)
    });
    E.on(searchInput, "blur", function(e) {
      setTimeout(blurHandle, 150)
    });
    setTimeout(blurHandle, 0)
  }, _handleSearchMonitor:function(form) {
    if(window.g_config && (appId = window.g_config.appId)) {
      sourceId = 16 === appId ? "ratez" : "shopz";
      (function(sourceId) {
        var input = document.createElement("input");
        input.setAttribute("type", "hidden");
        input.setAttribute("name", "initiative_id");
        function retDate() {
          var now = new Date;
          var month = now.getMonth() + 1;
          if(month < 10) {
            month = "0" + month
          }
          var date = now.getDate();
          if(date < 10) {
            date = "0" + date
          }
          return[now.getFullYear(), month, date].join("")
        }
        input.value = sourceId + "_" + retDate();
        D.append(input, form)
      })(sourceId)
    }
  }, _initArchive:function() {
    var self = this, popupTrigger = D.get(".rank-icon", self._mod), popupContent = D.get(".rank-popup", self._mod);
    new Overlay.Popup({srcNode:popupContent, trigger:popupTrigger, triggerType:"mouse", elStyle:{display:"block", visibility:"hidden", position:"absolute", left:"-9999px", top:"-9999px"}, align:{node:popupTrigger, points:["cr", "cl"], offset:[5, -5]}, effect:{effect:"slide", easing:"easeNone", duration:0.3}, zIndex:1E8})
  }, _initQS:function() {
    var self = this, qs = D.get(".qualification-service", self._mod), imgs = D.query("img", qs);
    if(S.UA.ie && S.UA.ie < 7) {
      S.each(imgs, function(img) {
        new Compatible(img, {png:true, png_tag:true})
      })
    }
  }, _initCustomerService:function() {
    var self = this, customerService = D.get(".customer-service", self._mod);
    S.ready(function() {
      self._handleWWMoveTips();
      var uls = S.Node.all("ul.service-group", customerService);
      if(uls.length > 0) {
        self._displayWWGroop(uls.item(uls.length - 1))
      }
    })
  }, _moreWWHide:function() {
    var self = this, moreWW = D.get(".more-WW", self._mod), allWW = D.query(".group", self._mod);
    if(allWW.length > 5) {
      for(var i = 5;i < allWW.length;i++) {
        D.css(allWW[i], "display", "none")
      }
      D.css(moreWW, "display", "block");
      var mouseLeaveTimer;
      E.on(moreWW, "click", function() {
        D.css(moreWW, "display", "none");
        for(var i = 5;i < allWW.length;i++) {
          D.css(allWW[i], "display", "block")
        }
        E.on(D.get(".customer-service", self._mod), "mouseleave", function() {
          if(mouseLeaveTimer) {
            mouseLeaveTimer.cancel()
          }
          mouseLeaveTimer = S.later(function() {
            for(var i = 5;i < allWW.length;i++) {
              D.css(allWW[i], "display", "none")
            }
            D.css(moreWW, "display", "block");
            mouseLeaveTimer.cancel()
          }, 300)
        })
      });
      E.on(moreWW, "mouseenter", function() {
        D.addClass(moreWW, "more-WW-hover")
      });
      E.on(moreWW, "mouseleave", function() {
        D.removeClass(moreWW, "more-WW-hover")
      })
    }
  }, _displayWWGroop:function(node) {
    var self = this, tempwangwang, templi, tempdesc, api = "http://amos.im.alisoft.com/", config = "v=2&site=cntaobao&s=1&charset=utf-8&uid=", url = node.attr("data-url"), nick = node.attr("data-nick"), gnick = node.attr("data-gnick"), groupIdFilter = node.attr("data-group-filter").split("@_@");
    node.children().innerHTML = null;
    if("" != url) {
      S.getScript(url, function() {
        if(!groupMember) {
          return
        }
        var group = eval("(" + groupMember + ")").groups;
        if("" != group && "" != groupIdFilter[0]) {
          var groupMembers = eval("(" + groupMember + ")").groups.group;
          S.each(groupMembers, function(item, temp) {
            if(S.inArray(groupMembers[temp].groupId.toString(), groupIdFilter) || groupIdFilter[0] == "all") {
              templi = D.create("<li>", {"class":"group"}), tempdesc = D.create("<span>", {"class":"groupname"});
              D.html(tempdesc, groupMembers[temp].groupName);
              tempwangwang = D.create("<a>", {href:api + "getcid.aw?v=3&uid=" + gnick + "&site=cntaobao&groupid=" + groupMembers[temp].groupId + "&s=1&charset=gbk&fromid=cntaobao" + S.Cookie.get("_nk_"), target:"_blank"});
              tempwangwang.appendChild(D.create("<img>", {src:api + "grponline.aw?v=3&uid=" + gnick + "&site=cntaobao&gids=" + groupMembers[temp].groupId + "&s=1", alt:"\ufffd\ufffd\ufffd\ufffd\ufffd\ufffd\ufffd\ufffd\ufffd\u04b7\ufffd\ufffd\ufffd\u03e2"}));
              templi.appendChild(tempdesc);
              D.insertAfter(tempwangwang, tempdesc);
              node.append(templi)
            }
          });
          self._moreWWHide()
        }else {
          templi = D.create("<li>", {"data-wangwang":"mainwangwang"}), tempdesc = D.create("<span>", {"class":"groupname"});
          D.html(tempdesc, "\ufffd\u0377\ufffd\ufffd\ufffd\ufffd\ufffd");
          tempwangwang = D.create("<a>", {href:api + "msg.aw?" + config + nick, target:"_blank"});
          tempwangwang.appendChild(D.create("<img>", {src:api + "online.aw?" + config + nick, alt:"\ufffd\ufffd\ufffd\ufffd\ufffd\ufffd\ufffd\ufffd\ufffd\u04b7\ufffd\ufffd\ufffd\u03e2"}));
          templi.appendChild(tempdesc);
          D.insertAfter(tempwangwang, tempdesc);
          node.append(templi)
        }
      })
    }
  }, _handleWWMoveTips:function() {
    DataStore.create();
    if(DataStore.get("knowWWMove") != "yes") {
      if(D.hasClass("#J_TWWMoveTip", "tip-hidden")) {
        D.removeClass("#J_TWWMoveTip", "tip-hidden")
      }
      E.add("#J_IKnow", "click", function(evt) {
        evt.preventDefault();
        DataStore.set("knowWWMove", "yes");
        D.addClass("#J_TWWMoveTip", "tip-hidden")
      })
    }
  }, _initCollect:function() {
    var self = this, container = D.get("#popupPanel", self._mod), triggers = D.query(".J_TCollectShop", self._mod), dialog;
    S.ready(function() {
      if(window.shop_config && window.shop_config.isView) {
        self._getCollectState()
      }
      self._handleTriggerCollect();
      self._getCollectCount();
      self._initShare()
    })
  }, _getCollectState:function() {
    var self = this, isLogin = C.get("_l_g_") && C.get("_nk_") || C.get("ck1") && C.get("tracknick"), triggers = D.query(".J_TCollectShop", self._mod), collectInit = D.get(".J_TCollectInit", self._mod);
    if(isLogin) {
      S.io({url:addTimeStamp(D.attr(collectInit, "data-init")), type:"post", dataType:"jsonp", success:function(result) {
        if(result && "1" === result.state) {
          if(result.isCollected) {
            self._handleCollectSuccess(triggers)
          }
        }
      }})
    }
  }, _handleTriggerCollect:function() {
    var self = this, container = D.get("#popupPanel", self._mod), triggers = D.query(".J_TCollectShop", self._mod), dialog;
    S.each(triggers, function(trigger) {
      dialog = new Overlay.Dialog({content:container, width:width, height:height, closable:false, align:{node:trigger, points:["bl", "tr"], offset:[-500, 0]}, elStyle:{position:"absolute"}, zIndex:1E8});
      E.on(trigger, "click", function(e) {
        if(!D.hasClass(trigger, "collected")) {
          e.preventDefault();
          D.css(container, {display:"block"});
          dialog.show()
        }else {
          if(D.hasClass(trigger, "collect-btn")) {
            e.preventDefault()
          }
        }
      });
      var width = trigger.getAttribute("data-width"), height = trigger.getAttribute("data-height");
      dialog.on("show", function() {
        var targetURL = addTimeStamp(trigger.href), html = '<a class="close-btn" href="#"' + 'style="position: absolute; top: 5px; right: 4px; outline: none;' + 'display: block; width: 15px; height: 15px; background: url(http://a.tbcdn.cn/app/tc/img/close_btn.png) no-repeat; text-decoration: none; text-indent: -99999px">X</a>' + '<iframe id="addIframe" src="' + targetURL + '" width="' + width + '" height="' + height + '" name="popupIframe" frameborder="0" scrolling="no"></iframe>';
        this.set("width", width);
        this.set("height", height);
        D.html(container, html);
        E.on(D.get(".close-btn", container), "click", function() {
          dialog.hide()
        });
        var iframe = D.get("#addIframe");
        if(iframe.attachEvent) {
          iframe.attachEvent("onload", function() {
            addSuccess()
          })
        }else {
          iframe.onload = function() {
            addSuccess()
          }
        }
        function addSuccess() {
          if(iframe.contentWindow._add_item) {
            self._handleCollectSuccess(triggers)
          }
        }
      })
    })
  }, _handleCollectSuccess:function(triggers) {
    S.each(triggers, function(trigger) {
      D.removeClass(trigger, "no-collect");
      D.addClass(trigger, "collected");
      if(D.hasClass(trigger, "collect-btn")) {
        D.text(trigger, "\ufffd\ufffd\ufffd\u0572\ufffd")
      }
      if(D.hasClass(trigger, "collect-area")) {
        D.attr(trigger, "title", "\ufffd\ufffd\ufffd\ufffd\ufffd\u0572\u0638\u00f5\ufffd\ufffd\u0323\ufffd\ufffd\ufffd\ufffd\ufffd\ufffd\ufffd\ufffd\u00f5\ufffd\ufffd\u033f\u057c\ufffd");
        D.attr(trigger, "href", D.attr(trigger, "data-href"))
      }
    })
  }, _getCollectCount:function() {
    var self = this, el = D.get("#J_TCollCount", self._mod), config, collCount;
    if(!el || !(config = S.unparam(el.getAttribute("data-info"))) || !el.getAttribute("data-info")) {
      return
    }
    S.io({url:addTimeStamp(config["countUrl"]) + "&keys=" + config["param"], type:"post", dataType:"jsonp", success:function(result) {
      var collCount = 0;
      if(result) {
        collCount = parseInt(result[config["param"]], 10);
        if(isNaN(collCount)) {
          collCount = 0
        }
        if(collCount >= 1E6) {
          collCount = Math.ceil(collCount / 1E4) + "\ufffd\ufffd"
        }
        el.innerHTML = '<a target="_blank" href="' + config["mecuryUrl"] + '">' + collCount + "</a>"
      }
    }})
  }, _initShare:function() {
    var self = this;
    S.getScript("http://a.tbcdn.cn/p/snsdk/core.js", {success:function() {
      var shareTrigger = D.get(".J_TShare", self._mod);
      E.on(shareTrigger, "click", function(ev) {
        ev.preventDefault();
        var configs = {comment:"\ufffd\ufffd\u04b5\uacbb\ufffd\ud8ec\ufffd\ufffd\ufffd\ufffd\ufffd\ufffd\u38e1\u03e3\ufffd\ufffd\ufffd\ufffd\u04b2\u03f2\ufffd\ufffd\u0176~", type:"shop", key:D.attr(shareTrigger, "data-id"), client_id:"10", ui:{isIframe:false, width:900, height:390}, callback:{failure:function() {
        }, success:function() {
        }}};
        SNS.login(function() {
          SNS.ui("share", configs)
        })
      })
    }})
  }});
  function addTimeStamp(url) {
    var now = S.now();
    return url + (url.indexOf("?") === -1 ? "?" : "&") + "t=" + now
  }
  TshopPsmShopHeader.selector = ".tshop-psm-shop-header";
  return TshopPsmShopHeader
}, {requires:["core", "cookie", "suggest", "overlay", "../widget/compatible"]});

