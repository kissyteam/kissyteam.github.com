KISSY.add("shop/mods/custom-banner", function(S, Core) {
  var S = KISSY, E = S.Event, D = S.DOM;
  function TshopPbsmShopCustomBanner(context) {
    var self = this;
    self._mod = context.mod;
    if(!self._mod) {
      return
    }
    self._init()
  }
  S.augment(TshopPbsmShopCustomBanner, {_init:function() {
    S.log("TshopPbsmShopCustomBanner init start")
  }});
  TshopPbsmShopCustomBanner.selector = ".tshop-pbsm-shop-banner";
  return TshopPbsmShopCustomBanner
}, {requires:["core"]});

