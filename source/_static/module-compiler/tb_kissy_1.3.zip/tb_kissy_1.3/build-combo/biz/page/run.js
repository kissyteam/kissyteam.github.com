KISSY.add("biz/page/run", function() {
}, {requires:["../y"]});

