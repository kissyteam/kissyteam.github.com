KISSY.add("biz/y", function() {
}, {requires:["./x"]});

