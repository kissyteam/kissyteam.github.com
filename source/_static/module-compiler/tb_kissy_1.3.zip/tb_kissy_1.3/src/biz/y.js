KISSY.add(function(){
},{
    requires:["./x"]
});