KISSY.add(function(S, y) {
  return"run + " + y
}, {requires:["../y"]});

